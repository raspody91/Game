import pygame
pygame.init()

width = 800
height = 800

clock = pygame.time.Clock()
fps = 60

bg_image = pygame.image.load("img/bg13.png")
bg_rect = bg_image.get_rect()

display = pygame.display.set_mode((width, height))
pygame.display.set_caption("Platformer")

class Hero:
    def __init__(self):
        self.image = pygame.image.load("img/player1.png")
        self.rect = self.image.get_rect()
        self.direction = 1

    def update(self):
        self.rect.x += self.direction
        if self.rect.right > width or self.rect.left < 0:
            self.direction *= -1
        display.blit(self.image, self.rect)
hero = Hero()
run = True
while run:
    display.blit(bg_image, bg_rect)
    hero.update()
    pygame.display.update()
pygame.quit()